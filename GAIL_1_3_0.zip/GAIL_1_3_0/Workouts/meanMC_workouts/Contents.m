% meanMC_workouts
%
% Files
%   Test_MeanMC_g - this is the driver file to test meanMC package
%   Ytrafficmodel - this is the Nagel-Schreckenberg traffic model 
%   dt_meanMC_g_TrafficModel - test traffic model
