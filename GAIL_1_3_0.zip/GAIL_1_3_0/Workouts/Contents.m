% WORKOUTS
%
% Folders
%   cubMC_workouts                  - workouts of cubMC_g method
%   meanMC_workouts                 - workouts of meanMC_g method
%   univariate_integration_workouts - workouts of univariate integration
%
% Files
%   longtests                       - lengthy tests of GAIL algorithms