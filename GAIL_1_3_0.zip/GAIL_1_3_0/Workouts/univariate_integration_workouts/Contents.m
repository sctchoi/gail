% UNIVARIATE_INTEGRATION_WORKOUTS
%
% Files
%
%   workout_integral_g    - Calls automatic guaranteed algorithm for univariate integration
%   ConesPaperIntegrationTest16-Aug-2013-12-24-10.mat - Result from
%   workout_integral_g
