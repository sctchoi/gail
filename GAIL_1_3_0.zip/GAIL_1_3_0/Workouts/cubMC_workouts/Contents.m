% CUBMC_WORKOUTS
%
% Files
%   genz_test_fun      - A suite of test functions from Alan Genz and Keister
%   genz_test_fun_true - Provides true integrals of seven test functions
%   test_cubMC_g       - Driver script to test the cubMC_g algorithm
%   dt_cubMC_g         - Lengthy doc tests for cubMC_g
