% CONESNOTBALLSPAPER
%
% Files
%   ConesPaperFoolFunctions   - Generate Figure 1. in Cones not ball paper Construct functions that fool QUAD or INTEGRAL like Lyness says
%   conepaper_test_integral_g - Generate Table 2. in Cones not ball paper Run automatic guaranteed algorithm for function integration
%   conepaper_test_funappx_g  - Generate Table 3. in Cones not ball paper Run automatic guaranteed algorithm for function approximation
%   foolfunmaker              - Generata fooling function in Cones not ball paper
%   Cones not ball.pdf        - Paper 
