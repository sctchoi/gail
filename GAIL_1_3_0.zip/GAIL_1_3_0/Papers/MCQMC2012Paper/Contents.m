% MCQMC2012PAPER   
%
% Folders
% 
%   MCQMC_Paper_Scripts             - Scripts of three examples in MCQMC paper
%
% Files
%
%   AdaptiveMCProbErrAnal_rev_m.pdf - Monte Carlo and Quasi-Monte Carlo Methods 2012 paper 
