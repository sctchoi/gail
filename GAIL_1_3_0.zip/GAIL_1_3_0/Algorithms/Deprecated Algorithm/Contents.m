% DEPRECATED ALGORITHM
%
% Files
%   funappxtau_g  - One dimensional guaranteed function recovery on interval [0,1] with cone condition tau
%   integraltau_g - 1-D guaranteed function integration using trapezoidal rule
%   funappx01_g   - One-dimensional guaranteed function recovery on interval [0,1]
%   integral01_g  - 1-D guaranteed function integration using trapezoidal rule
