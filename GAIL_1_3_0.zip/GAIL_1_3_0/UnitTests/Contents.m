% UNITTESTS
%
% Files
%
%   dt_funappx_g      - fast doc tests for funappx_g
%   dt_integral_g     - fast doc tests for integral_g
%   ut_funappx_g      - unit test for funappx_g
%   runtests          - Drives all doctests and unit tests
%   ut_cubMC_g        - coming soon
%   ut_integral_g     - unit test for integral_g
%   ut_meanMC_g       - unit test for meanMC_g
%   ut_funappx01_g    - unit test for funappx01_g
%   ut_integral01_g   - unit test for integral_g
