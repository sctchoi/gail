%GAILPUBLISH  To generate html files in the GAIL subdirectory Documentation
 publish('GAIL');
 publish('funclist');
 publish('help_funappx_g');
 publish('help_integral_g');
 publish('help_meanMC_g');
 publish('help_cubMC_g');