function b=isposge3(a)
%
% ISPOSGE3 To judge if a variable is greater than or equal to 3
b = isnumeric(a) && (a>=3);