function b=isposge2(a)
%
% ISPOSGE2 To judge if a variable is greater than or equal to 2
b = isnumeric(a) && (a>=2);