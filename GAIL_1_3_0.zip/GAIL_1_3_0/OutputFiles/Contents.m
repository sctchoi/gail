% OUTPUTFILES
%
% Folders
% ConesPaperOutput    - output files of cones paper
% MCQMCPaperOutput    - output files of MCQMC paper