% CONESPAPEROUTPUT
%
% Files
%
% ConesPaperFunAppxTest-03-Sep-2013-18-37-05 --- dataset of function
% approximation in Cones paper
% ConesPaperIntegralTest-03-Sep-2013-22-46-01 --- dataset of integral in
% Cones paper
% ConesPaperFlukyquad --- figure 1b) in Cones paper
% ConesPaperSpikyquad --- figure 1a) in Cones Paper
%