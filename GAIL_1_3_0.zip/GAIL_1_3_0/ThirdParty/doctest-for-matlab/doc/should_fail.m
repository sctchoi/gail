% Has a doctest that should fail.
%
% >> 3 + 3
% 
% ans =
%
%      5
%
