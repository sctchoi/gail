% DOCUMENTATION
%
% Files
%   funclist        - Functions
%   GAIL            - GAIL
%   help_cubMC_g    - cubMC_g
%   help_funappx_g  - funappx_g
%   help_integral_g - integral_g
%   help_meanMC_g   - meanMC_g
%   help_funappxab_g - funappxab_g
%
% Folders
%   html            - folder of all html files